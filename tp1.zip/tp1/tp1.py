# tp1.py
# Marc Edwards
# mpedward


from cmu_112_graphics import * # graphics
from bs4 import BeautifulSoup # scraping
import pandas as pd # beautiful dataframes
import plotly.express as px # visuals
import xlrd # read excel files helper
import csv # create csv files
import requests # also a scraping method
import lxml.html as lh # parsing



### Using pandas and bs4 for webscraping purposes
# using requests and bs4 together

# odds tables
# method from
# https://pythonprogramming.net/tables-xml-scraping-parsing-beautiful-soup-tutorial/
# https://www.pluralsight.com/guides/extracting-data-html-beautifulsoup

urlOdds = "https://www.teamrankings.com/nfl/odds/"
rawUrlOdds = requests.get(urlOdds).text
soupOdds = BeautifulSoup(rawUrlOdds, "lxml")
oddsTable = soupOdds.find("table") 
oddsTableData = oddsTable.find_all("tr")
oddsTableHeader = oddsTable.find_all("thead")
oddsTableBody = oddsTable.find_all("tbody")

for thead in oddsTableHeader:
    th = thead.find_all("th")
    headerRow = [h.text for h in th]
    #print(headerRow)

# biggest line moves, found at bottom of page
# think this will be good for analysis
for tr in oddsTableData:
    td = tr.find_all("td")
    rowOdds = [i.text for i in td]
    #print(rowOdds)



'''
# Sourced from
# https://www.pluralsight.com/guides/extracting-data-html-beautifulsoup

oddsTable = soup.find("table", attrs = {"class": "coupon-row-item"})
# this pulls out the header row in the table
oddsTableData = oddsTable.find_all("tr")
print(oddsTableData) # returns the row of the header of the table I want

for tr in oddsTableData:
    td = tr.find_all('td')
    row = [i.text for i in td]
    print(row) # returning an empty list?'''


'''
# requests Method
url = "https://www.marathonbet.com/en/betting/American+Football/NFL+-+65517?interval=ALL_TIME"
betterUrl = requests.get(url)
# contents of the page
content = lh.fromstring(betterUrl.content)
#Parse data that are stored between <tr>..</tr> of HTML
tableElements = content.xpath('//table')
# print(tableElements)'''


######

# records against spread
# method from

# https://pythonprogramming.net/tables-xml-scraping-parsing-beautiful-soup-tutorial/

urlATS = "https://www.teamrankings.com/nfl/trends/ats_trends/"
# gets everything from html page
rawUrlATS = requests.get(urlATS).text
soupATS = BeautifulSoup(rawUrlATS, "lxml")
atsTable = soupATS.find("table") 
atsTableData = atsTable.find_all("tr")
atsTableHeader = atsTable.find_all("thead")

#ATS Record: The number of ATS covers, no-covers, and pushes
#Cover %: The percentage of time the team covered, net of pushes
#MOV: The average margin of victory (negative in losses)
#ATS +/-: The average amount of points that the team covers the spread by

# headers
for thead in atsTableHeader:
    th = thead.find_all("th")
    headerRow = [h.text for h in th]
    #print(headerRow)

# body data, no headers, creating dictionary
for tr in atsTableData:
    td = tr.find_all("td")
    row = [i.text for i in td]
    if row == []: # removes empty list at top
        pass
    else:
        colTeam = row[0]
        colRecord = row[1]
        colCover = row[2]
        colMOV = float(row[3])
        colATS = row[4]
        #print(colTeam)
        # create dictionary to store the info
        atsDict = {"Team": colTeam, "ATS Record": colRecord, 
                        "Cover %": colCover, "MOV": colMOV,
                        "ATS +/-": colATS}
        #print(atsDict)
        # turn it into a dateframe as well
        dfATS = pd.DataFrame(atsDict, columns = headerRow, index = [0])
        #print(dfATS)
        # turn the dataframe into a readable .csv file
        #dfATS.to_csv("atsDict.csv", index = False)
        #dfATS = pd.DataFrame(atsDict, columns = headerRow)

# https://towardsdatascience.com/how-to-export-pandas-dataframe-to-csv-2038e43d9c03
# dfATS = pd.DataFrame(atsDict, columns = headerRow, index = [1])
# taking data and turning it into a dictionary

# cannot create dataframe bacuse I'm creating the dictionary in the loop
# and else statement above



### pandas and read_csv
# reading a csv for tech demo, and modifying with pandas for demo

#https://www.sportsbookreviewsonline.com/scoresoddsarchives/nfl/nfloddsarchives.htm

df20_21 = pd.read_excel(open("nfl odds 2020-21.xlsx", "rb"))
df20_21.insert(0, "Season", len(df20_21)*["2020-21"], True)

df19_20 = pd.read_excel(open("nfl odds 2019-20.xlsx", "rb"))
df19_20.insert(0, "Season", len(df19_20)*["2019-20"], True)

# combine the dfs of each season
combinedDf = pd.concat([df20_21, df19_20]) # master of pandas

### plotly

# basic example for tech demo
# showing the count of the ampunt of times each team appears in the 
# in the 19-20 dataframe
# a lot of options for visuals can come from plotly
histEx = px.histogram(df19_20, x =  "Team", color_discrete_sequence = ["red"])
#histEx.show() # shows the graph when running'''




### cmu graphics stuff
### basic overlay for UI
### does not do anything productive yet,
### cmu_112_graphics compatable
### methods are from previous things we learned in class

def appStarted(app):
    app.waitingForFirstKeyPress = True
    initRestart(app)
    pass

def initRestart(app):
    app.gameOver = False

def linesAndOdds(app):
    pass

def historyResults(app):
    combinedDf

# event key and mouse pressed for interaction
def keyPressed(app, event):
    if (app.waitingForFirstKeyPress):
        app.waitingForFirstKeyPress = False
    elif (event.key == "r"):
        df20_21 = pd.read_excel(open("nfl odds 2020-21.xlsx", "rb"))
        df20_21.insert(0, "Season", len(df20_21)*["2020-21"], True)
        df19_20 = pd.read_excel(open("nfl odds 2019-20.xlsx", "rb"))
        df19_20.insert(0, "Season", len(df19_20)*["2019-20"], True)
        # combine the dfs of each season
        combinedDf = pd.concat([df20_21, df19_20]) # master of pandas
        print(combinedDf)

    elif (event.key == "l"):
        for thead in oddsTableHeader:
            th = thead.find_all("th")
            headerRow = [h.text for h in th]
            print(headerRow)

        # biggest line moves, found at bottom of page
        # think this will be good for analysis
        for tr in oddsTableData:
            td = tr.find_all("td")
            rowOdds = [i.text for i in td]
            print(rowOdds)

    elif (event.key == "h"):
        for tr in atsTableData:
            td = tr.find_all("td")
            row = [i.text for i in td]
            if row == []: # removes empty list at top
                pass
            else:
                colTeam = row[0]
                colRecord = row[1]
                colCover = row[2]
                colMOV = float(row[3])
                colATS = row[4]
                #print(colTeam)
                atsDict = {"Team": colTeam, "ATS Record": colRecord, 
                                "Cover %": colCover, "MOV": colMOV,
                                "ATS +/-": colATS}
                print(atsDict)

        

# splash page for instructions how to use
def drawSplashPage(app, canvas):
    canvas.create_text(app.width//2, app.height//2, 
    text="FEPO.bet", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2 + 15, 
    text="Press L to get latest results and lines", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2 + 30, 
    text="Press H to get game summaries and team performances", 
    font='Arial 16 bold')

    canvas.create_text(app.width//2, app.height//2 + 45, 
    text="Press R to get game results from previous seasons and through last week", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2 + 60,
    text = "Press Q to quit and return to the homepage (this page)",
    font = "Arial 16 bold")

# need to figure out how to draw and print the actual stuff into the window

def redrawAll(app, canvas):
    if (app.waitingForFirstKeyPress):
        drawSplashPage(app, canvas)
    else:
        pass

runApp(width=800, height=600)
