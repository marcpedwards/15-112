# tp0.py
# Marc Edwards
# mpedward


from cmu_112_graphics import * # graphics
from bs4 import BeautifulSoup # scraping
import pandas as pd # beautiful dataframes
import numpy as np # not using, erase later
import plotly.express as px 
import xlrd # read excel files helper
import csv # create csvs

import requests # also a scrapoing method
import lxml.html as lh # parsing
import time # ??
from datetime import datetime # ??
from urllib.request import urlopen # stack overflow (link later) $ prob not gonna use
#import re

### Using pandas and bs4 for webscraping purposes
# using requests and bs4 together

url = "https://www.marathonbet.com/en/betting/American+Football/NFL+-+65517?interval=ALL_TIME"
# gets everything from html page
rawUrl = requests.get(url).text
soup = BeautifulSoup(rawUrl, "lxml")
#print(soup.prettify())
#print(soup.title.text)

# Sourced from
# https://www.pluralsight.com/guides/extracting-data-html-beautifulsoup

oddsTable = soup.find("table", attrs = {"class": "coupon-row-item"})
# this pulls out the header row in the table
oddsTableData = oddsTable.find_all("tr")
print(oddsTableData) # returns the row of the header of the table I want

# test to get headings
#headings = []
#for td in oddsTableData.find_all("td"):
    # remove any newlines and extra spaces from left and right
    #headings.append(td.b.text.replace('\n', ' ').strip())
#print(headings)

for tr in oddsTableData:
    td = tr.find_all('td')
    row = [i.text for i in td]
    print(row) # returning an empty list?



# requests Method
url = "https://www.marathonbet.com/en/betting/American+Football/NFL+-+65517?interval=ALL_TIME"
betterUrl = requests.get(url)
# contents of the page
content = lh.fromstring(betterUrl.content)
#Parse data that are stored between <tr>..</tr> of HTML
tableElements = content.xpath('//table')
print(tableElements)

### pandas and read_csv
# reading a csv for tech demo, and modifying with pandas for demo
df20_21 = pd.read_excel(open("nfl odds 2020-21.xlsx", "rb"))
df20_21.insert(0, "Season", len(df20_21)*["2020-21"], True)

df19_20 = pd.read_excel(open("nfl odds 2019-20.xlsx", "rb"))
df19_20.insert(0, "Season", len(df19_20)*["2019-20"], True)

# combine the dfs of each season
combinedDf = pd.concat([df20_21, df19_20]) # master of pandas

### plotly

# basic example for tech demo
# showing the count of the ampunt of times each team appears in the 
# in the 19-20 dataframe
# a lot of optioins for visuals can come from plotly
histEx = px.histogram(df19_20, x =  "Team", color_discrete_sequence = ["red"])
#histEx.show() # shows the graph when running
# not yet compatible with cmu_112_graphics, well idk how to do it yet



### cmu graphics stuff
### basic overlay for UI
### does not do anything productive yet
def appStarted(app):
    app.waitingForFirstKeyPress = True
    initRestart(app)
    pass

def initRestart(app):
    app.gameOver = False

def linesAndOdds(app):
    pass

def historyResults(app):
    combinedDf

# event key and mouse pressed for interaction
def keyPressed(app, event):
    if (app.waitingForFirstKeyPress):
        app.waitingForFirstKeyPress = False
    elif (event.key == "r"):
        df20_21 = pd.read_excel(open("nfl odds 2020-21.xlsx", "rb"))
        df20_21.insert(0, "Season", len(df20_21)*["2020-21"], True)
        df19_20 = pd.read_excel(open("nfl odds 2019-20.xlsx", "rb"))
        df19_20.insert(0, "Season", len(df19_20)*["2019-20"], True)
        # combine the dfs of each season
        combinedDf = pd.concat([df20_21, df19_20]) # master of pandas
        print(combinedDf)
    elif (event.key == "l"):
        linesAndOdds(app)
    elif (event.key == "h"):
        historyResults(app)

        

# splash page for instructions how to use
def drawSplashPage(app, canvas):
    canvas.create_text(app.width//2, app.height//2, 
    text="FEPO.bet", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2+15, 
    text="Press L to get latest results and lines", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2+30, 
    text="Press H to get Historical Results", 
    font='Arial 16 bold')
    
    canvas.create_text(app.width//2, app.height//2 + 45,
    text = "Press R to return to the homepage (this page)",
    font = "Arial 16 bold")

def redrawAll(app, canvas):
    if (app.waitingForFirstKeyPress):
        drawSplashPage(app, canvas)
    else:
        pass

runApp(width=800, height=600)

